// Firebase Security Rules untuk Kementerian Transmigrasi
// File: firebase-rules.js

// ========================================
// FIRESTORE SECURITY RULES
// ========================================

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // ========================================
    // USER MANAGEMENT RULES
    // ========================================
    
    // Users collection - role-based access
    match /users/{userId} {
      // Allow users to read their own profile
      allow read: if request.auth != null && 
        (request.auth.uid == userId || 
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role in ['super_admin', 'admin']);
      
      // Allow users to update their own profile (limited fields)
      allow update: if request.auth != null && 
        request.auth.uid == userId &&
        request.resource.data.diff(resource.data).affectedKeys()
          .hasOnly(['displayName', 'phone', 'notes', 'updatedAt']);
      
      // Allow super admin and admin to create/update/delete users
      allow create, update, delete: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role in ['super_admin', 'admin'];
      
      // Validate user data structure
      allow create, update: if request.auth != null &&
        request.resource.data.keys().hasAll(['email', 'displayName', 'role', 'satuanKerja']) &&
        request.resource.data.role in ['super_admin', 'admin', 'user', 'viewer'] &&
        request.resource.data.email is string &&
        request.resource.data.displayName is string &&
        request.resource.data.satuanKerja is string;
    }
    
    // ========================================
    // SATUAN KERJA RULES
    // ========================================
    
    // Satuan kerja master data
    match /satuan_kerja/{satkerId} {
      // Anyone can read satuan kerja data
      allow read: if request.auth != null;
      
      // Only super admin can modify
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'super_admin';
    }
    
    // ========================================
    // SATKER DATA RULES (Progress Data)
    // ========================================
    
    match /satker_data/{dataId} {
      // Users can read data from their own satuan kerja
      allow read: if request.auth != null && 
        (resource.data.satuanKerja == get(/databases/$(database)/documents/users/$(request.auth.uid)).data.satuanKerja ||
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role in ['super_admin', 'admin']);
      
      // Users can create data for their own satuan kerja
      allow create: if request.auth != null && 
        request.resource.data.satuanKerja == get(/databases/$(database)/documents/users/$(request.auth.uid)).data.satuanKerja &&
        request.resource.data.userId == request.auth.uid;
      
      // Users can update their own data
      allow update: if request.auth != null && 
        resource.data.userId == request.auth.uid &&
        request.resource.data.satuanKerja == resource.data.satuanKerja;
      
      // Admin can update data within their satuan kerja
      allow update: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'admin' &&
        resource.data.satuanKerja == get(/databases/$(database)/documents/users/$(request.auth.uid)).data.satuanKerja;
      
      // Super admin can update any data
      allow update: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'super_admin';
      
      // Only super admin can delete
      allow delete: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'super_admin';
      
      // Validate data structure
      allow create, update: if request.auth != null &&
        request.resource.data.keys().hasAll(['satuanKerja', 'userId', 'timestamp']) &&
        request.resource.data.satuanKerja is string &&
        request.resource.data.userId is string &&
        request.resource.data.timestamp is timestamp;
    }
    
    // ========================================
    // REPORTS & ANALYTICS RULES
    // ========================================
    
    // Reports collection
    match /reports/{reportId} {
      // Users can read reports from their satuan kerja
      allow read: if request.auth != null && 
        (resource.data.satuanKerja == get(/databases/$(database)/documents/users/$(request.auth.uid)).data.satuanKerja ||
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role in ['super_admin', 'admin']);
      
      // Only admin and super admin can create reports
      allow create: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role in ['super_admin', 'admin'];
      
      // Only creator or super admin can update/delete
      allow update, delete: if request.auth != null && 
        (resource.data.createdBy == request.auth.uid ||
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'super_admin');
    }
    
    // ========================================
    // AUDIT LOGS RULES
    // ========================================
    
    // Audit logs for system activities
    match /audit_logs/{logId} {
      // Only super admin can read audit logs
      allow read: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'super_admin';
      
      // System can create audit logs
      allow create: if request.auth != null;
      
      // No updates or deletes allowed
      allow update, delete: if false;
    }
    
    // ========================================
    // SYSTEM CONFIG RULES
    // ========================================
    
    // System configuration
    match /system_config/{configId} {
      // Only super admin can read/write system config
      allow read, write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'super_admin';
    }
    
    // ========================================
    // BACKUP & EXPORT RULES
    // ========================================
    
    // Backup data
    match /backups/{backupId} {
      // Only super admin can access backups
      allow read, write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'super_admin';
    }
    
    // ========================================
    // NOTIFICATIONS RULES
    // ========================================
    
    // User notifications
    match /notifications/{notificationId} {
      // Users can read their own notifications
      allow read: if request.auth != null && 
        resource.data.userId == request.auth.uid;
      
      // System can create notifications
      allow create: if request.auth != null;
      
      // Users can mark their notifications as read
      allow update: if request.auth != null && 
        resource.data.userId == request.auth.uid &&
        request.resource.data.diff(resource.data).affectedKeys().hasOnly(['isRead', 'readAt']);
      
      // No deletes allowed
      allow delete: if false;
    }
    
    // ========================================
    // TEMPORARY DATA RULES
    // ========================================
    
    // Temporary data for forms, sessions, etc.
    match /temp_data/{tempId} {
      // Users can access their own temp data
      allow read, write: if request.auth != null && 
        resource.data.userId == request.auth.uid;
      
      // Auto-delete after 24 hours (handled by Cloud Functions)
      allow create: if request.auth != null;
    }
    
    // ========================================
    // DEFAULT DENY RULE
    // ========================================
    
    // Deny all other access
    match /{document=**} {
      allow read, write: if false;
    }
  }
}

// ========================================
// STORAGE SECURITY RULES
// ========================================

rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    
    // User profile pictures
    match /profile_pictures/{userId}/{fileName} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        request.auth.uid == userId &&
        request.resource.size < 5 * 1024 * 1024 && // 5MB max
        request.resource.contentType.matches('image/.*');
    }
    
    // Document uploads
    match /documents/{satuanKerja}/{userId}/{fileName} {
      allow read: if request.auth != null && 
        (resource.metadata.userId == request.auth.uid ||
         get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role in ['super_admin', 'admin']);
      
      allow write: if request.auth != null && 
        request.auth.uid == userId &&
        request.resource.size < 10 * 1024 * 1024 && // 10MB max
        request.resource.contentType.matches('application/pdf|application/msword|application/vnd.openxmlformats-officedocument.wordprocessingml.document|image/.*');
    }
    
    // System files
    match /system/{fileName} {
      allow read, write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.role == 'super_admin';
    }
    
    // Default deny
    match /{allPaths=**} {
      allow read, write: if false;
    }
  }
}

// ========================================
// AUTHENTICATION RULES
// ========================================

// Note: Firebase Auth rules are configured in the Firebase Console
// These are the recommended settings:

/*
1. Enable Email/Password authentication
2. Enable Google Sign-in
3. Set authorized domains:
   - localhost
   - 127.0.0.1
   - Your production domain
4. Configure password policies:
   - Minimum length: 8 characters
   - Require uppercase, lowercase, numbers
5. Set session timeout: 1 hour
6. Enable email verification
7. Configure password reset
*/

// ========================================
// CLOUD FUNCTIONS TRIGGERS
// ========================================

/*
Recommended Cloud Functions to implement:

1. onUserCreate - Send welcome email, create user profile
2. onUserDelete - Clean up user data, revoke access
3. onDataCreate - Validate data, send notifications
4. onDataUpdate - Track changes, update audit logs
5. autoBackup - Daily backup of critical data
6. dataCleanup - Remove old temporary data
7. userActivity - Track user login/logout activity
8. roleChange - Handle role changes and permissions
*/

// ========================================
// IMPLEMENTATION NOTES
// ========================================

/*
1. Deploy these rules to Firebase Console:
   - Go to Firestore Database > Rules
   - Copy and paste the rules above
   - Click "Publish"

2. Deploy Storage rules:
   - Go to Storage > Rules
   - Copy and paste the storage rules above
   - Click "Publish"

3. Test the rules:
   - Use Firebase Emulator for local testing
   - Test with different user roles
   - Verify data isolation works correctly

4. Monitor usage:
   - Check Firebase Console for rule violations
   - Monitor security events
   - Review access patterns

5. Regular updates:
   - Review rules monthly
   - Update based on new requirements
   - Test after any changes
*/

// ========================================
// SECURITY BEST PRACTICES
// ========================================

/*
1. Always validate data on both client and server
2. Use Firebase Auth for authentication
3. Implement proper error handling
4. Log all security events
5. Regular security audits
6. Keep dependencies updated
7. Use HTTPS in production
8. Implement rate limiting
9. Monitor for suspicious activity
10. Regular backup and recovery testing
*/
