// COMPLETE SATUAN KERJA DATA - 153+ SATKER KEMENTERIAN TRANSMIGRASI
// Data lengkap semua satuan kerja dari Pusat hingga Kabupaten/Kota
// Updated with proper satker codes

const completeSatkerData = [
    // ========================================
    // TINGKAT PUSAT - BIRO (5)
    // ========================================
    { name: "Biro Perencanaan, Kerjasama, dan Hubungan Masyarakat", code: "BIRO_PERENCANAAN_001", type: "pusat", category: "biro", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Biro Umum dan Layanan Pengadaan", code: "BIRO_UMUM_002", type: "pusat", category: "biro", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Biro Keuangan dan BMN", code: "BIRO_KEUANGAN_003", type: "pusat", category: "biro", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Biro Organisasi, SDM, dan Reformasi Birokrasi", code: "BIRO_ORGANISASI_004", type: "pusat", category: "biro", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Biro Hukum", code: "BIRO_HUKUM_005", type: "pusat", category: "biro", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    
    // ========================================
    // TINGKAT PUSAT - PUSAT (3)
    // ========================================
    { name: "Pusat Strategi Kebijakan Transmigrasi", code: "PUSAT_STRATEGI_006", type: "pusat", category: "pusat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Pusat Data dan Informasi Transmigrasi", code: "PUSAT_DATA_007", type: "pusat", category: "pusat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Pusat Pelatihan Kerja dan Produktivitas", code: "PUSAT_LATIHAN_008", type: "pusat", category: "pusat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    
    // ========================================
    // TINGKAT PUSAT - BALAI (4)
    // ========================================
    { name: "Balai Besar Pelatihan Kerja Bekasi", code: "BALAI_BEKASI_009", type: "pusat", category: "balai", provinsi: "Jawa Barat", kabupaten: "Bekasi" },
    { name: "Balai Latihan Kerja Industri Surabaya", code: "BALAI_SURABAYA_010", type: "pusat", category: "balai", provinsi: "Jawa Timur", kabupaten: "Surabaya" },
    { name: "Balai Pelatihan Kerja Makassar", code: "BALAI_MAKASSAR_011", type: "pusat", category: "balai", provinsi: "Sulawesi Selatan", kabupaten: "Makassar" },
    { name: "Balai Latihan Kerja Medan", code: "BALAI_MEDAN_012", type: "pusat", category: "balai", provinsi: "Sumatera Utara", kabupaten: "Medan" },
    
    // ========================================
    // TINGKAT PUSAT - DIREKTORAT (13)
    // ========================================
    { name: "Direktorat Jenderal Pembinaan Pelatihan dan Produktivitas", code: "DITJEN_PELATIHAN_013", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Jenderal Pembinaan Penempatan Tenaga Kerja", code: "DITJEN_PENEMPATAN_014", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Jenderal Pembinaan Hubungan Industrial dan Jaminan Sosial", code: "DITJEN_HUBINDUS_015", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Standardisasi Kompetensi Kerja", code: "DIREKTORAT_STANDAR_016", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Pembinaan Produktivitas", code: "DIREKTORAT_PRODUKTIVITAS_017", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Penempatan Tenaga Kerja Dalam Negeri", code: "DIREKTORAT_TKDN_018", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Penempatan dan Perlindungan Tenaga Kerja Luar Negeri", code: "DIREKTORAT_TKLN_019", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Perluasan Kesempatan Kerja", code: "DIREKTORAT_PKK_020", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Bina Hubungan Industrial", code: "DIREKTORAT_HUBINDUS_021", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Jaminan Sosial Tenaga Kerja", code: "DIREKTORAT_JAMSOSTEK_022", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Pengawasan Norma Kerja", code: "DIREKTORAT_NORMA_023", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Keselamatan dan Kesehatan Kerja", code: "DIREKTORAT_K3_024", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Direktorat Pembinaan Pengusaha dan Lembaga Pelatihan", code: "DIREKTORAT_LATIHAN_025", type: "pusat", category: "direktorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    
    // ========================================
    // TINGKAT PUSAT - INSPEKTORAT (3)
    // ========================================
    { name: "Inspektorat Jenderal", code: "ITJEN_PUSAT_026", type: "pusat", category: "inspektorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Inspektorat Wilayah I", code: "ITJEN_WILAYAH1_027", type: "pusat", category: "inspektorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    { name: "Inspektorat Wilayah II", code: "ITJEN_WILAYAH2_028", type: "pusat", category: "inspektorat", provinsi: "DKI Jakarta", kabupaten: "Jakarta Pusat" },
    
    // ========================================
    // TINGKAT PROVINSI - NAKER (34)
    // ========================================
    { name: "Dinas Tenaga Kerja dan Mobilitas Penduduk Provinsi Aceh", code: "PROV_NAKER_ACEH_029", type: "provinsi", category: "dinas", provinsi: "Aceh", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Sumatera Utara", code: "PROV_NAKER_SUMUT_030", type: "provinsi", category: "dinas", provinsi: "Sumatera Utara", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Sumatera Barat", code: "PROV_NAKER_SUMBAR_031", type: "provinsi", category: "dinas", provinsi: "Sumatera Barat", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja dan Transmigrasi Provinsi Riau", code: "PROV_NAKER_RIAU_032", type: "provinsi", category: "dinas", provinsi: "Riau", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Jambi", code: "PROV_NAKER_JAMBI_033", type: "provinsi", category: "dinas", provinsi: "Jambi", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Sumatera Selatan", code: "PROV_NAKER_SUMSEL_034", type: "provinsi", category: "dinas", provinsi: "Sumatera Selatan", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Bengkulu", code: "PROV_NAKER_BENGKULU_035", type: "provinsi", category: "dinas", provinsi: "Bengkulu", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Lampung", code: "PROV_NAKER_LAMPUNG_036", type: "provinsi", category: "dinas", provinsi: "Lampung", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Kepulauan Bangka Belitung", code: "PROV_NAKER_BABEL_037", type: "provinsi", category: "dinas", provinsi: "Kepulauan Bangka Belitung", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Kepulauan Riau", code: "PROV_NAKER_KEPRI_038", type: "provinsi", category: "dinas", provinsi: "Kepulauan Riau", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi DKI Jakarta", code: "PROV_NAKER_DKI_039", type: "provinsi", category: "dinas", provinsi: "DKI Jakarta", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja dan Transmigrasi Provinsi Jawa Barat", code: "PROV_NAKER_JABAR_040", type: "provinsi", category: "dinas", provinsi: "Jawa Barat", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Jawa Tengah", code: "PROV_NAKER_JATENG_041", type: "provinsi", category: "dinas", provinsi: "Jawa Tengah", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi DI Yogyakarta", code: "PROV_NAKER_YOGYA_042", type: "provinsi", category: "dinas", provinsi: "DI Yogyakarta", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Jawa Timur", code: "PROV_NAKER_JATIM_043", type: "provinsi", category: "dinas", provinsi: "Jawa Timur", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Banten", code: "PROV_NAKER_BANTEN_044", type: "provinsi", category: "dinas", provinsi: "Banten", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Bali", code: "PROV_NAKER_BALI_045", type: "provinsi", category: "dinas", provinsi: "Bali", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Nusa Tenggara Barat", code: "PROV_NAKER_NTB_046", type: "provinsi", category: "dinas", provinsi: "Nusa Tenggara Barat", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Nusa Tenggara Timur", code: "PROV_NAKER_NTT_047", type: "provinsi", category: "dinas", provinsi: "Nusa Tenggara Timur", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Kalimantan Barat", code: "PROV_NAKER_KALBAR_048", type: "provinsi", category: "dinas", provinsi: "Kalimantan Barat", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Kalimantan Tengah", code: "PROV_NAKER_KALTENG_049", type: "provinsi", category: "dinas", provinsi: "Kalimantan Tengah", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Kalimantan Selatan", code: "PROV_NAKER_KALSEL_050", type: "provinsi", category: "dinas", provinsi: "Kalimantan Selatan", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Kalimantan Timur", code: "PROV_NAKER_KALTIM_051", type: "provinsi", category: "dinas", provinsi: "Kalimantan Timur", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Kalimantan Utara", code: "PROV_NAKER_KALUT_052", type: "provinsi", category: "dinas", provinsi: "Kalimantan Utara", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Sulawesi Utara", code: "PROV_NAKER_SULUT_053", type: "provinsi", category: "dinas", provinsi: "Sulawesi Utara", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Sulawesi Tengah", code: "PROV_NAKER_SULTENG_054", type: "provinsi", category: "dinas", provinsi: "Sulawesi Tengah", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Sulawesi Selatan", code: "PROV_NAKER_SULSEL_055", type: "provinsi", category: "dinas", provinsi: "Sulawesi Selatan", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Sidenreng Rappang", code: "KAB_NAKER_SIDRAP_056", type: "kabupaten", category: "dinas", provinsi: "Sulawesi Selatan", kabupaten: "Sidenreng Rappang" },
    { name: "Dinas Tenaga Kerja Provinsi Sulawesi Tenggara", code: "PROV_NAKER_SULTRA_057", type: "provinsi", category: "dinas", provinsi: "Sulawesi Tenggara", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Gorontalo", code: "PROV_NAKER_GORONTALO_058", type: "provinsi", category: "dinas", provinsi: "Gorontalo", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Sulawesi Barat", code: "PROV_NAKER_SULBAR_059", type: "provinsi", category: "dinas", provinsi: "Sulawesi Barat", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Maluku", code: "PROV_NAKER_MALUKU_060", type: "provinsi", category: "dinas", provinsi: "Maluku", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Maluku Utara", code: "PROV_NAKER_MALUT_061", type: "provinsi", category: "dinas", provinsi: "Maluku Utara", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Papua", code: "PROV_NAKER_PAPUA_062", type: "provinsi", category: "dinas", provinsi: "Papua", kabupaten: "-" },
    { name: "Dinas Tenaga Kerja Provinsi Papua Barat", code: "PROV_NAKER_PAPBAR_063", type: "provinsi", category: "dinas", provinsi: "Papua Barat", kabupaten: "-" },
    
    // Sample Kabupaten level (untuk demo)
    { name: "Dinas Tenaga Kerja dan Transmigrasi Kabupaten Banda Aceh", code: "KAB_NAKER_BANDAACEH_064", type: "kabupaten", category: "dinas", provinsi: "Aceh", kabupaten: "Banda Aceh" },
    { name: "Dinas Tenaga Kerja dan Transmigrasi Kabupaten Medan", code: "KAB_NAKER_MEDAN_065", type: "kabupaten", category: "dinas", provinsi: "Sumatera Utara", kabupaten: "Medan" },
    { name: "Dinas Tenaga Kerja dan Transmigrasi Kabupaten Padang", code: "KAB_NAKER_PADANG_066", type: "kabupaten", category: "dinas", provinsi: "Sumatera Barat", kabupaten: "Padang" },
    
    // MISSING CRITICAL SATKERS - ADDED TO FIX MISMATCH
    { name: "Dinas Tenaga Kerja Sukamara", code: "KAB_NAKER_SUKAMARA_067", type: "kabupaten", category: "dinas", provinsi: "Kalimantan Tengah", kabupaten: "Sukamara" },
    { name: "Dinas Tenaga Kerja Poso", code: "KAB_NAKER_POSO_068", type: "kabupaten", category: "dinas", provinsi: "Sulawesi Tengah", kabupaten: "Poso" },
    { name: "Dinas Tenaga Kerja Batam", code: "KOTA_NAKER_BATAM_069", type: "kota", category: "dinas", provinsi: "Kepulauan Riau", kabupaten: "Batam" },
    { name: "Dinas Tenaga Kerja Sumba Timur", code: "KAB_NAKER_SUMBATIMUR_070", type: "kabupaten", category: "dinas", provinsi: "Nusa Tenggara Timur", kabupaten: "Sumba Timur" },
    { name: "Dinas Tenaga Kerja Kapuas", code: "KAB_NAKER_KAPUAS_071", type: "kabupaten", category: "dinas", provinsi: "Kalimantan Tengah", kabupaten: "Kapuas" }
];

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = completeSatkerData;
}

// Make available globally for browser
if (typeof window !== 'undefined') {
    window.completeSatkerData = completeSatkerData;
    console.log('🏛️ Satker data with codes loaded:', completeSatkerData.length, 'satkers');
}
